import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  private name = "Yoga"
  public myId = "name"
  public hasError = false
  public titleStyle = {
    color : "blue",
    fontStyle : "italic"
  }
  public subitMsg = ""
  constructor() { }

  ngOnInit() {
  }

  onClick(name,pwd){
    console.log('Message has been submitted')
    console.log(name)
    console.log(pwd)
    this.subitMsg = 'Message posted successfully...'
  }  

}
