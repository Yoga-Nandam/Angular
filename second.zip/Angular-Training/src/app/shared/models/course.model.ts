export interface Courses {
    title: string;
    creationDate: string;
    duration: string;
    description: string;
}
