import { CourseSearchPipe } from './course-search.pipe';

describe('CourseSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new CourseSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
