import { Pipe, PipeTransform } from '@angular/core';
import { Courses } from 'src/app/shared/models/course.model';
import * as _ from 'lodash';

@Pipe({
  name: 'courseSearch'
})
export class CourseSearchPipe implements PipeTransform {

  transform(value: Courses[], field : string): Courses[] {
    return _.filter(value, field);
  }

}
