import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseHeaderComponent } from './course-header/course-header.component';
import { CourseSearchComponent } from './course-search/course-search.component';
import { AddCourseComponent } from './add-course/add-course.component';
import { FormsModule } from '@angular/forms';
import { CourseSearchPipe } from './directives/course-search.pipe';


@NgModule({
  declarations: [CourseHeaderComponent, CourseSearchComponent, AddCourseComponent,CourseSearchPipe],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [
    CourseHeaderComponent, CourseSearchComponent, AddCourseComponent
  ]
})
export class BreadcrumbsModule { }
