import { Component, OnInit } from '@angular/core';
import { CourseSearchPipe } from '../directives/course-search.pipe';
import { AppHelper } from 'src/app/shared/utils/app-helper';
import * as _ from 'lodash';


@Component({
  selector: 'app-course-search',
  templateUrl: './course-search.component.html',
  styleUrls: ['./course-search.component.css'],
  providers: [ CourseSearchPipe ],
})
export class CourseSearchComponent implements OnInit {

  searchText: string;
  
  constructor(private courseSearch : CourseSearchPipe) { }

  ngOnInit() {
  }

  search(){
    let courses = AppHelper.getMockCourses();
    let result = courses.filter(data => data.title.toLowerCase().includes(this.searchText.toLowerCase()));
    console.log(result);
  }

}
