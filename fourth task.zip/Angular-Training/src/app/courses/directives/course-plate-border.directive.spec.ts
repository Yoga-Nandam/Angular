import { CoursePlateBorderDirective } from './course-plate-border.directive';

describe('CoursePlateBorderDirective', () => {
  it('should create an instance', () => {
    const directive = new CoursePlateBorderDirective();
    expect(directive).toBeTruthy();
  });
});
