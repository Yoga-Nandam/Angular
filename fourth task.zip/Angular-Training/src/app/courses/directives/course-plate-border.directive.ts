import { Directive, OnInit, ElementRef, Renderer2, Input } from '@angular/core';

@Directive({
  selector: '[appCoursePlateBorder]'
})
export class CoursePlateBorderDirective implements OnInit {
 
  @Input() creationDate : string;

  greenBorder = '1px solid green';
  blueBorder = '1px solid blue';
  whiteBorder = '1px solid white';


  constructor(private elementRef: ElementRef, private renderer: Renderer2) {}

  ngOnInit(): void {
    this.setCourseBorder(new Date(this.creationDate));
  }

  setCourseBorder(creationDate : Date){
    let now = new Date();
    let fourteenDaysBack = new Date();
    fourteenDaysBack =  new Date(fourteenDaysBack.setDate(now.getDate()-14));
    if(creationDate.getTime() < now.getTime()  && creationDate.getTime() >= fourteenDaysBack.getTime()){
      this.renderer.setStyle(
        this.elementRef.nativeElement,
        'border',
        this.greenBorder
      )
    }
    else if(creationDate.getTime()>now.getTime()){
      this.renderer.setStyle(
        this.elementRef.nativeElement,
        'border',
        this.blueBorder
      )
    }

    else{
      this.renderer.setStyle(
        this.elementRef.nativeElement,
        'border',
        this.whiteBorder
      )
    }
  }
}
