import { Pipe, PipeTransform } from '@angular/core';
import * as _ from 'lodash';
import { Courses } from 'src/app/shared/models/course.model';

@Pipe({
  name: 'courseSort'
})
export class CourseSortPipe implements PipeTransform {

  transform(value: Courses[], field : string): Courses[] {
    return _.orderBy(value, field);
  }

}
