import { TimeConversionPipe } from './time-conversion.pipe';

describe('TimeConversionPipe', () => {
  it('create an instance', () => {
    const pipe = new TimeConversionPipe();
    expect(pipe).toBeTruthy();
  });
});
