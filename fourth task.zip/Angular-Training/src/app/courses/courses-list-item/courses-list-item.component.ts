import { Component, OnInit, Input } from '@angular/core';
import { Courses } from '../../shared/models/course.model';

@Component({
  selector: 'app-courses-list-item',
  templateUrl: './courses-list-item.component.html',
  styleUrls: ['./courses-list-item.component.css']
})
export class CoursesListItemComponent implements OnInit {

  @Input() public courseList: Courses;
  
  constructor() { }

  ngOnInit() {
  }

  editCourse() {
    console.log('EDIT COURSE');
  }

  deleteCourse() {
    console.log('DELETE COURSE');
  }

}
