import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CoursesListComponent } from './courses-list/courses-list.component';
import { CoursesListItemComponent } from './courses-list-item/courses-list-item.component';
import { CoursePlateBorderDirective } from './directives/course-plate-border.directive';
import { TimeConversionPipe } from './pipes/time-conversion.pipe';
import { CourseSortPipe } from './pipes/course-sort.pipe';
import { CourseSearchPipe } from '../breadcrumbs/directives/course-search.pipe';



@NgModule({
  declarations: [CoursesListComponent, CoursesListItemComponent,CoursePlateBorderDirective, TimeConversionPipe, CourseSortPipe],
  imports: [
    CommonModule
  ],
  exports: [
    CoursesListComponent,
    CoursesListItemComponent
  ]
})
export class CoursesModule { }
