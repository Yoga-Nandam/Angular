import { Injectable } from '@angular/core';
import { AppHelper } from '../shared/utils/app-helper';

@Injectable({
  providedIn: 'root'
})
export class CourseService {

 constructor() { }

  getCourseList(){
    return AppHelper.getMockCourses();
  }


}
