import { Observable, Subject, from } from 'rxjs';
import { Courses } from '../models/course.model';
import { AppHelper } from '../utils/app-helper';

export class MockService {

    mockDataObservable : Subject<Courses[]>;

    getMockData(): Observable<Courses>{
        return from(AppHelper.getMockCourses());
    }

    updateMockData( courses : Courses[]){
        this.mockDataObservable.next(courses);
    }
}
