import { MockService } from './mock-service';

describe('MockService', () => {
  it('should create an instance', () => {
    expect(new MockService()).toBeTruthy();
  });
});
