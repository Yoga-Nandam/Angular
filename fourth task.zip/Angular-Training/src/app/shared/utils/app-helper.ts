import { Courses } from '../models/course.model';

export class AppHelper {

    static mockCourses: Courses[] = [
        {
          title: "Javascript",
          creationDate: "Fri Nov 15 2019 22:33:10 GMT+0530 (India Standard Time)",
          duration: 244,
          description: "Learn about where you can find course descriptions, what information they include, how they work, and details about various components of a course description. Course descriptions report information about a university or college's classes. They're published both in course catalogs that outline degree requirements and in course schedules that contain descriptions for all courses offered during a particular semester.",
          topRated : true,
        },
        {
          title: "Angular",
          creationDate: "Fri Nov 29 2019 22:33:10 GMT+0530 (India Standard Time)",
          duration: 120,
          description: "Learn about where you can find course descriptions, what information they include, how they work, and details about various components of a course description. Course descriptions report information about a university or college's classes. They're published both in course catalogs that outline degree requirements and in course schedules that contain descriptions for all courses offered during a particular semester.",
          topRated : false,
        },
        {
          title: "Python",
          creationDate: "Fri Nov 22 2019 22:33:10 GMT+0530 (India Standard Time)",
          duration: 56,
          description: "Learn about where you can find course descriptions, what information they include, how they work, and details about various components of a course description. Course descriptions report information about a university or college's classes. They're published both in course catalogs that outline degree requirements and in course schedules that contain descriptions for all courses offered during a particular semester.",
          topRated : false,
        },
        
      ];

      static getMockCourses(): Courses[]{
        return AppHelper.mockCourses;
      }
}
