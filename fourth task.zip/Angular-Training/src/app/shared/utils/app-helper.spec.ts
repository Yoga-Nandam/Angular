import { AppHelper } from './app-helper';

describe('AppHelper', () => {
  it('should create an instance', () => {
    expect(new AppHelper()).toBeTruthy();
  });
});
