export interface Courses {
    title: string;
    creationDate: string;
    duration: number;
    description: string;
    topRated : boolean;
}
