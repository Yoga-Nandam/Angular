import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CoursesListItemComponent } from './courses-list-item.component';
import { CUSTOM_ELEMENTS_SCHEMA, Component } from '@angular/core';
import { CourseService } from '../course.service';
import { Courses } from 'src/app/shared/models/course.model';

describe('CoursesListItemComponent', () => {
  let component: CoursesListItemComponent;
  let fixture: ComponentFixture<CoursesListItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CoursesListItemComponent,],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();

  }));

  beforeEach( () => {
    fixture = TestBed.createComponent(CoursesListItemComponent);
    let course = {
            title: "Video Course 1. Name Tag",
            creationDate: "1 Jan,2019",
            duration: "1h 30m",
            description: "Learn about where you can find course descriptions, what information they include, how they work, and details about various components of a course description. Course descriptions report information about a university or college's classes. They're published both in course catalogs that outline degree requirements and in course schedules that contain descriptions for all courses offered during a particular semester.",
          };
    component = fixture.componentInstance;
    component.courseList = course;
    fixture.detectChanges();
    spyOn(console, 'log');
  
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


it('should call console.log when editCourse is called', () => {
    component.editCourse();
    expect(console.log).toHaveBeenCalled();
  });

  it('should call console.log when deleteCourse is called', () => {
    component.deleteCourse();
    expect(console.log).toHaveBeenCalled();
  });

});



