import { Component, OnInit } from '@angular/core';
import { Courses } from '../../shared/models/course.model';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-courses-list',
  templateUrl: './courses-list.component.html',
  styleUrls: ['./courses-list.component.css']
})
export class CoursesListComponent implements OnInit {

 courseList : Courses[];

  constructor(
    private courseService : CourseService
  ) { }

  ngOnInit() {
    this.courseList = this.courseService.getCourseList();
  }

  loadMore(){
    console.log("Load More");
  }

}
