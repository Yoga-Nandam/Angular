export interface Users {
    id: string;
    firstName: string;
    lastName: string;
}
