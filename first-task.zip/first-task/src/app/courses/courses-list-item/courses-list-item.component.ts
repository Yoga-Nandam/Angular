import { Component, OnInit, Input } from '@angular/core';
import { Courses } from '../course.model';

@Component({
  selector: 'app-courses-list-item',
  templateUrl: './courses-list-item.component.html',
  styleUrls: ['./courses-list-item.component.css']
})
export class CoursesListItemComponent implements OnInit {

  @Input() public courseList: Courses;
  constructor() { }

  ngOnInit() {
  }

}
