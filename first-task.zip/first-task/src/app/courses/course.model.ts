export interface Courses {
    id: string;
    title: string;
    creationDate: string;
    duration: string;
    description: string;
}
