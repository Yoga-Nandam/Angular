import { Component, OnInit } from '@angular/core';
import { Courses } from '../course.model';

@Component({
  selector: 'app-courses-list',
  templateUrl: './courses-list.component.html',
  styleUrls: ['./courses-list.component.css']
})
export class CoursesListComponent implements OnInit {

  public courseList: Courses[] = [
    {
      id: "1",
      title: "Angular",
      creationDate: "1 Jan,2019",
      duration: "1h 30m",
      description: "Course Description",
    },
    {
      id: "2",
      title: "Angular",
      creationDate: "1 Jan,2019",
      duration: "1h 30m",
      description: "Course Description",
    },
    {
      id: "3",
      title: "Angular",
      creationDate: "1 Jan,2019",
      duration: "1h 30m",
      description: "Course Description",
    },
    {
      id: "4",
      title: "Angular",
      creationDate: "1 Jan,2019",
      duration: "1h 30m",
      description: "Course Description",
    }
  ];

  constructor() { }

  ngOnInit() {
  }

}
