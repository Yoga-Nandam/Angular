import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseHeaderComponent } from './course-header/course-header.component';
import { CourseSearchComponent } from './course-search/course-search.component';
import { AddCourseComponent } from './add-course/add-course.component';



@NgModule({
  declarations: [CourseHeaderComponent, CourseSearchComponent, AddCourseComponent],
  imports: [
    CommonModule
  ],
  exports: [
    CourseHeaderComponent, CourseSearchComponent, AddCourseComponent
  ]
})
export class BreadcrumbsModule { }
